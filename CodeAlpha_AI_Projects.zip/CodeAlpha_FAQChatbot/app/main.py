import streamlit as st
from src.chatbot import FAQChatbot

bot = FAQChatbot("data/faqs.csv")
st.title("FAQ Chatbot")
q = st.text_input("Ask a question")
if st.button("Ask"):
    st.write(bot.get_response(q))
