import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class FAQChatbot:
    def __init__(self, path):
        self.df = pd.read_csv(path)
        self.vectorizer = TfidfVectorizer(stop_words="english")
        self.vecs = self.vectorizer.fit_transform(self.df["question"])

    def get_response(self, q):
        if not q.strip():
            return "Ask something!"
        v = self.vectorizer.transform([q])
        sims = cosine_similarity(v, self.vecs).flatten()
        idx = sims.argmax()
        return self.df.iloc[idx]["answer"]
