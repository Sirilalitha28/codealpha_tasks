import streamlit as st
from src.translator import translate_text

LANGUAGE_MAP = {"English": "en","Hindi":"hi","Telugu":"te","Tamil":"ta","Kannada":"kn","French":"fr","German":"de","Spanish":"es"}

st.title("Language Translation Tool")
text_input = st.text_area("Enter text")
src = st.selectbox("Source", list(LANGUAGE_MAP.keys()))
tgt = st.selectbox("Target", list(LANGUAGE_MAP.keys()))
if st.button("Translate"):
    st.write(translate_text(text_input, LANGUAGE_MAP[src], LANGUAGE_MAP[tgt]))
