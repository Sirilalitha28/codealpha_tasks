from deep_translator import GoogleTranslator
def translate_text(text, src, tgt):
    if not text.strip():
        return ""
    return GoogleTranslator(source=src, target=tgt).translate(text)
