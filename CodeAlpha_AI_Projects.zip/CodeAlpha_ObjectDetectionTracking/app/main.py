import cv2
from src.detector import ObjectDetector

det = ObjectDetector("models/yolov3.cfg","models/yolov3.weights","models/coco.names")
cap = cv2.VideoCapture(0)

while True:
    ok, frame = cap.read()
    if not ok: break
    dets = det.detect_and_track(frame)
    for d in dets:
        x,y,w,h = d["box"]
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
    cv2.imshow("Detection", frame)
    if cv2.waitKey(1)&0xFF==ord('q'): break

cap.release()
cv2.destroyAllWindows()
