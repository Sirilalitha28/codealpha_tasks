# placeholder minimal file (real weights needed)
class ObjectDetector:
    def __init__(self,cfg,wts,names): pass
    def detect_and_track(self,frame): return []
